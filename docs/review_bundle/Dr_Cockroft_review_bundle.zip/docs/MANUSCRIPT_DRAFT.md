# Manuscript Draft

## Working Title

Leakage-Audited Hierarchical and Single-Head CNNs for Brain MRI Tumor and Dementia Image Classification

## Abstract Draft

This study evaluates convolutional neural network classifiers for brain MRI image categorization across tumor and dementia datasets. We compare a hierarchical pipeline, consisting of a binary tumor-versus-dementia router followed by domain-specific subtype classifiers, against a single 8-class CNN baseline. Because initial strict-test performance was near-perfect, we performed image-hash leakage audits before defining publishable results. The first full audit identified exact cross-split duplicate leakage, so final model claims use a de-duplicated retraining run that assigns exact duplicate SHA-256 image groups to a single split before augmentation. The accepted exact-deduplicated CNN suite reached 0.9963 hierarchical accuracy and 0.9972 single 8-class accuracy on the strict test split. A conservative perceptual-hash sensitivity run, which also grouped identical dHash fingerprints into one split, retained strong performance with 0.9894 hierarchical accuracy and 0.9906 single 8-class accuracy. Multimodal vision-language model experiments, including zero-shot, hierarchical prompting, and LoRA adaptation, were substantially weaker for direct image classification. These results support CNNs as the primary image classifiers for this dataset, while emphasizing source-bias limitations and the need for external validation.

## Methods Draft

Images were treated as brain MRI scans. The brain tumor dataset contains glioma, meningioma, no-tumor, and pituitary classes. The dementia dataset contains MildDemented, ModerateDemented, NonDemented, and VeryMildDemented classes. Splits were generated before augmentation. Tumor images from the official Testing folder were preferentially held out as test data, while dementia images were deterministically stratified because no official dementia test split was available.

Brain tumor MRI images were sourced from the public Kaggle Brain Tumor MRI Dataset by Masoud Nickparvar. Dementia MRI images were sourced from the public Kaggle Alzheimer's Disease Multiclass Images Dataset by Aryan Singhal, an augmented and upsampled derivative dataset. The dementia data card cites UraninJo's Augmented Alzheimer MRI Dataset V2 as its upstream source, which in turn references Tourist55's Alzheimer's Dataset (4 class of Images). Full provenance notes and citation drafts are maintained in `docs/DATASET_PROVENANCE.md`.

The primary training manifest grouped exact duplicate SHA-256 image hashes into a single split to prevent identical pixels from appearing across train, validation, and test partitions. Training augmentation was applied only to training images and included horizontal flips, rotation, and contrast jitter. Validation and test transforms were limited to resizing, tensor conversion, and normalization.

The hierarchical architecture used a ResNet50 binary router to classify images as tumor or dementia, followed by an EfficientNet-B3 tumor specialist or MobileNetV3 dementia specialist. The comparison baseline used a single EfficientNet-B3 head over all eight classes. Training used ImageNet-pretrained backbones, class-weighted cross-entropy, label smoothing, random erasing, AdamW optimization, stronger weight decay, and early stopping.

Publication readiness was assessed with duplicate-path checks, exact SHA-256 cross-split overlap checks, perceptual dHash cross-split overlap checks, train-validation gap summaries, strict-test metrics, and confusion matrices. A corrected perceptual-hash sensitivity run was performed after aligning the manifest-builder dHash implementation with the audit implementation.

Multimodal vision-language model experiments were run on Kaggle using Qwen and SmolVLM candidates with strict JSON prompts, hierarchical prompts, and Qwen2.5-VL-3B LoRA adaptation. These models were evaluated separately from the CNN classifiers.

## Results Draft

The initial full audit found 782 exact cross-split SHA-256 overlap rows and was therefore treated as a blocking leakage risk. After exact-duplicate grouping and retraining, exact cross-split overlaps were reduced to 0, missing files remained 0, and no train-validation overfitting gap flags were found. The accepted exact-deduplicated CNN run achieved:

- Binary router: 1.0000 accuracy.
- Tumor specialist: 0.9792 accuracy.
- Dementia specialist: 0.9991 accuracy.
- Hierarchical CNN: 0.9963 accuracy.
- Single 8-class CNN: 0.9972 accuracy.

The exact-deduplicated audit still reported identical perceptual dHash values across splits. Because dHash is coarse for MRI slices and can group visually similar but non-identical images, this was treated as a sensitivity question rather than an automatic blocker. A corrected dHash-grouped sensitivity run produced 0 exact overlaps, 0 perceptual dHash overlaps, 0 missing files, and 0 train-validation gap flags. Under that stricter split, performance remained high:

- Binary router: 1.0000 accuracy.
- Tumor specialist: 0.9539 accuracy.
- Dementia specialist: 0.9975 accuracy.
- Hierarchical CNN: 0.9894 accuracy.
- Single 8-class CNN: 0.9906 accuracy.

The single 8-class CNN slightly outperformed the hierarchical CNN in both the accepted exact-deduplicated run and the conservative dHash sensitivity run. The hierarchical design remains useful for interpretability and domain-specific error analysis, but the single-head baseline should be reported as the top strict-test performer.

Probability-level evidence was generated from the accepted checkpoints without retraining. The tumor specialist reached ROC AUC 0.9975 and average precision 0.9875 with expected calibration error 0.0372. The dementia specialist reached ROC AUC 1.0000 and average precision 1.0000 with expected calibration error 0.0386. The single 8-class CNN reached ROC AUC 0.9979 and average precision 0.9969 with expected calibration error 0.1327. The hierarchical CNN reached ROC AUC 0.9968 and average precision 0.9907 with expected calibration error 0.1526. These results support strong discrimination while showing that softmax confidence should not be interpreted as calibrated clinical probability.

Multimodal VLMs were not competitive as direct MRI classifiers. The best flat zero-shot VLM result was Qwen2.5-VL-7B at 0.1750 accuracy. Qwen2.5-VL-3B with LoRA improved to 0.3125 accuracy but showed label collapse. The best hierarchical VLM diagnostic reached 0.8750 broad-domain accuracy but only 0.2250 routed 8-class accuracy.

## Tables And Figures

Primary generated tables:

- `docs/DATASET_PROVENANCE.md`
- `docs/MANUSCRIPT_FULL_DRAFT.md`
- `docs/PUBLICATION_RESULTS_TABLES.md`
- `docs/publication_cnn_results.csv`
- `docs/publication_audit_checks.csv`
- `docs/publication_vlm_results.csv`
- `docs/PUBLICATION_FIGURES.md`
- `docs/FIGURE_CAPTIONS.md`
- `docs/PUBLICATION_EVIDENCE_RESULTS.md`
- `docs/PUBLICATION_SUBMISSION_STATUS.md`
- `training_logs/publication_evidence/PUBLICATION_EVIDENCE_SUMMARY.md`

Recommended figures:

- Figure 1: Dataset and splitting workflow, including exact-hash and dHash audit stages (`docs/figures/figure1_workflow.png`).
- Figure 2: Model architecture comparison: hierarchical router plus specialists versus single 8-class CNN (`docs/figures/figure2_architecture.png`).
- Figure 3: Accepted exact-deduplicated confusion matrices for tumor, dementia, hierarchical, and single 8-class CNNs (`docs/figures/figure3_exact_dedup_confusion.png`).
- Figure 4: Conservative dHash sensitivity confusion matrices for tumor, dementia, hierarchical, and single 8-class CNNs (`docs/figures/figure4_dhash_sensitivity_confusion.png`).
- Figure 5: Multimodal VLM comparison showing direct VLM classification failure relative to CNNs (`docs/figures/figure5_cnn_vlm_comparison.png`).
- Figure 6: Calibration curves and confidence histograms for accepted CNN checkpoints (`docs/figures/figure6_calibration_confidence.png`).
- Figure 7: ROC and precision-recall curves for accepted CNN checkpoints (`docs/figures/figure7_roc_pr_curves.png`).

## Limitations

The binary router may exploit dataset/source differences because tumor and dementia images originate from separate source datasets. Dementia results may be optimistic because no official external dementia holdout split was available. The dHash sensitivity run reduces near-duplicate split risk, but dHash is still a coarse perceptual fingerprint rather than a patient-level grouping method. Confidence calibration is imperfect, especially for the 8-class and hierarchical models, so softmax confidence should be reported as model confidence rather than clinical probability. The study should not make clinical deployment claims without independent external MRI validation and patient-level metadata.

## Ethics And Data Availability Draft

This study used publicly available, de-identified image datasets from Kaggle. No patient-level identifiers, acquisition metadata, or institutional clinical records were available to the investigators. Because only public de-identified datasets were used, institutional review board review and informed consent were not sought for this computational analysis. The absence of patient-level metadata prevents patient-level split validation and is reported as a limitation.

The raw images are not redistributed in this repository. They can be obtained from the cited Kaggle dataset pages subject to their current terms and licenses. Derived manifests, evaluation metrics, confusion matrices, calibration summaries, probability outputs, and manuscript figures are included in this repository to support reproducibility of the reported results.

## Submission Checklist

- Confirm all final tables are regenerated with `python3 scripts/build_publication_tables.py`.
- Confirm the publication package gate passes with `python3 scripts/check_publication_package.py`.
- Re-check `docs/DATASET_PROVENANCE.md` against the live Kaggle data cards and target venue requirements.
- Use `docs/MANUSCRIPT_FULL_DRAFT.md` as the current full-paper source when adapting to a journal or conference template.
- Use exact-deduplicated CNN results as the primary table.
- Include the dHash sensitivity table as robustness evidence.
- Include calibration, ROC, and precision-recall evidence from `training_logs/publication_evidence/`.
- Include the initial leakage audit as a methodological correction, not as a final result.
- Report VLM experiments as negative direct-classification results.
- Avoid clinical claims beyond this dataset.

## Specialist explainability review supplement

The accepted specialist checkpoints are evaluated without retraining using `scripts/build_explainability_bundle.py`. Figures 8a–8b provide separately selected error/low-confidence galleries; a seeded sample of 32 images per class per specialist supports descriptive perturbation and image-border diagnostics. Results and methods are in [the review bundle](review_bundle/README.md) and [quantitative summary](review_bundle/explainability/SUMMARY.md). The full manuscript contains the corresponding Methods and Results additions. These diagnostics do not establish anatomical correctness, calibrated clinical probabilities, absence of source bias, or external validity. Public-data, patient-metadata, and external-validation limitations remain unchanged.
